module.exports = {
    id: 0,
    firstName: '',
    lastName: '',
    email: '',
    isAdmin: false
}
