# eui starter app

## Development server

````npm start```` to start the angular project

````npm run start-proxy```` to start the angular project with json-server proxy mock server

````npm run build```` to build, lint and test your project for DEV

````npm run build-prod```` to build, lint and test your project for PROD

## Further help

http://eui.ecdevops.eu

register on [slack](https://ec-eui.slack.com).
