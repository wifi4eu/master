// This variable will be set to "dev", "test", or "prod" automatically by the Continuous Delivery deployment script.
var OPENID_LOGIN_ENVIRONMENT = "local";
