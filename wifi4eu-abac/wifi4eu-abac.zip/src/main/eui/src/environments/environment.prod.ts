export const environment = {
    production: true,
    enableDevToolRedux: false,
    modules: {
        // CORE
        core: {
            api: {
                base: '',
            },
        },
    }
};
