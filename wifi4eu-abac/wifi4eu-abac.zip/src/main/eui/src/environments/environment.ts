export const environment = {
    production: false,
    enableDevToolRedux: true,
};
