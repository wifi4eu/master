export const GLOBAL = {
    appTitle: 'eUI-app',
    languages: ['en', 'fr'],
    defaultLanguage: 'en',
    i18nFolder: 'i18n'
};
