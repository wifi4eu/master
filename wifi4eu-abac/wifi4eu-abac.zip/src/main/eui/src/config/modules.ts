export const MODULES = {
    core: {
        api: {
            base: '/api',
            user: {
                base: '',
                detail: '/user-details',
            },
        },
    },
};
