@javax.xml.bind.annotation.XmlSchema(namespace = "http://ec.europa.eu/sg/hrs/types", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package generated.hrs.ws.model;
