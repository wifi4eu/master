package wifi4eu.wifi4eu.abac.data.enums;

public enum NotificationStatus {
    PENDING,
    SENT
}
