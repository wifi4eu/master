package wifi4eu.wifi4eu.abac.data.enums;

public enum NotificationType {

    LEF_CREATION,
    BC_CREATION,
    LC_CREATION
}
