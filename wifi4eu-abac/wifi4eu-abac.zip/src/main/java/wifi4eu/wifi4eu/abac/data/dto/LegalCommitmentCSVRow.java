package wifi4eu.wifi4eu.abac.data.dto;

public class LegalCommitmentCSVRow {
	
	private Long municipalityPortalId;
	
	public Long getMunicipalityPortalId() {
		return municipalityPortalId;
	}
	
	public void setMunicipalityPortalId(Long municipalityPortalId) {
		this.municipalityPortalId = municipalityPortalId;
	}
}
